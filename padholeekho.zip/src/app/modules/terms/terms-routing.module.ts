import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { TermsComponent } from '../terms';

const routes: Routes = [  
  {
    path: '',
    component: TermsComponent,
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class TermsRoutingModule { }
