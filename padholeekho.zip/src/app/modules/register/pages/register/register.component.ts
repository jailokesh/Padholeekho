import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RegisterService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm = new FormGroup({
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phone: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
  });
  isLoading: boolean;
  error: any;

  constructor(
    private registerService: RegisterService,
    private router: Router,
  ) { }

  ngOnInit() { 
  }

  register() {
    this.registerService.registerApi(this.registerForm.value).pipe(
      tap(response => {
        console.log(response)
        if (response.status == 'success' && response.data.temp_user_id && response.data.register_exp) {
          this.router.navigate(['/OTP', { tempUserId: response.data.temp_user_id, registerExp: response.data.register_exp }]);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

}
