import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OtpService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit {
  otpForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean;
  error: any;
  data: any;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private otpService: OtpService,
    private formBuilder: FormBuilder
  ) {
    this.activatedRoute.params.subscribe(params => {
      if (params) {
        console.log(params);
        this.data = params;
      }
    });
    this.otpForm = this.formBuilder.group({
      oneInputOtp: [null, [Validators.required, Validators.min(1), Validators.max(1), Validators.pattern(/^[0-9]+$/)]],
      twoInputOtp: [null, [Validators.required, Validators.min(1), Validators.max(1), Validators.pattern(/^[0-9]+$/)]],
      threeInputOtp: [null, [Validators.required, Validators.min(1), Validators.max(1), Validators.pattern(/^[0-9]+$/)]],
      fourInputOtp: [null, [Validators.required, Validators.min(1), Validators.max(1), Validators.pattern(/^[0-9]+$/)]]
    })
  }

  get f() { return this.otpForm.controls; }

  ngOnInit() {
  }

  verifyOtp() {
    this.submitted = true;
    if (this.otpForm.invalid) {
      return;
    }
    this.data['register_exp'] = `${this.otpForm.value.oneInputOtp + this.otpForm.value.twoInputOtp + this.otpForm.value.threeInputOtp + this.otpForm.value.fourInputOtp}`;
    this.otpService.verifyOtpApi(this.data).pipe(
      tap(response => {
        console.log(response);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  resendOtpApi() {
    delete this.data['register_exp'];
    this.otpService.resendOtpApi(this.data).pipe(
      tap(response => {
        console.log(response);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

}
