import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class OtpService {

  constructor(
    private apiService: ApiService
  ) { }

  verifyOtpApi(data): Observable<any> {
    return this.apiService.post('/api/rest/authentication/signup/verify', data);
  }

  resendOtpApi(data): Observable<any> {
    return this.apiService.post('api/rest/authentication/signup/resend', data);
  }

}
