import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnquiryComponent } from './pages/enquiry/enquiry.component';
import { EnquiryRoutingModule } from './enquiry-routing.module';

@NgModule({
  declarations: [EnquiryComponent],
  imports: [
    CommonModule,
    EnquiryRoutingModule
  ]
})
export class EnquiryModule { }
