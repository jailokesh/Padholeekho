/* .....Footer..... */

export * from './footer/footer.component';

/* ......Header..... */

export * from './header/header.component';

/* ......Module Route.... */

export * from './moduleRoute/moduleRoute';