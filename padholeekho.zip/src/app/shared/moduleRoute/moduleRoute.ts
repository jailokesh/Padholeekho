import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    { path: 'aboutUs', loadChildren: './modules/about/about.module#AboutModule' },
    { path: 'enquiry', loadChildren: './modules/enquiry/enquiry.module#EnquiryModule' },
    { path: 'login', loadChildren: './modules/login/login.module#LoginModule' },
    { path: 'OTP', loadChildren: './modules/otp/otp.module#OtpModule' },
    { path: 'register', loadChildren: './modules/register/register.module#RegisterModule' },
    { path: 'support', loadChildren: './modules/support/support.module#SupportModule' },
    { path: 'terms', loadChildren: './modules/terms/terms.module#TermsModule' },
    { path: 'refund', loadChildren: './modules/refund/refund.module#RefundModule' },
    { path: 'privacy', loadChildren: './modules/privacy/privacy.module#PrivacyModule' },
    { path: 'wishlist', loadChildren: './modules/wishlist/wishlist.module#WishlistModule'},
    { path: 'cart', loadChildren:'./modules/cart/cart.module#CartModule'},
    { path: 'myProfile', loadChildren:'./modules/my-profile/my-profile.module#MyProfileModule'},
];