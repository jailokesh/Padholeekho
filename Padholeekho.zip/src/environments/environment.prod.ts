export const environment = {
  production: true,
  server_url: 'http://34.93.95.64/padholeekho/public'
};
