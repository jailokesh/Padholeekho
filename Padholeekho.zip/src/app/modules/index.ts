/* .......All Module Export Features...... */
 
export * from './about/about.module';
export * from './enquiry/enquiry.module';
export *from './home/home.module'
export * from './login/login.module';
export * from './otp/otp.module'; 
export * from './privacy/privacy.module';
export * from './refund/refund.module';
export * from './register/register.module';
export * from './support/support.module'; 
export * from './terms/terms.module';
export * from './wishlist/wishlist.module';
export * from './my-profile/my-profile.module';
export * from './privacy/privacy.module';
export * from './competitive/competitive.module';

