/* ......All Terms Export Features....... */
export * from './pages/terms/terms.component';