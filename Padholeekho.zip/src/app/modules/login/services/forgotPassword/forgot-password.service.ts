import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  constructor( private apiService: ApiService ) { }

  forgotpasswordApi(data):Observable<any> {
    return this.apiService.post('/api/rest/authentication/forgot-password/send', data)
  }

}
