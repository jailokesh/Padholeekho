import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { RegisterService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { MustMatch } from '../../../../shared'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  error: any;
  message: any;

  constructor(
    private registerService: RegisterService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.registerForm = this.formBuilder.group({
      name: ["", [Validators.required]],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      password: ["", [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: MustMatch('password', 'confirmPassword') });
  }

  get f() {
    return this.registerForm.controls;
  }

  ngOnInit() {

  }

  register() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    this.isLoading = true;
    this.registerService.registerApi(this.registerForm.value).pipe(
      tap(response => {
        console.log(response);
        this.message = response.response.message;
        if (response.status == 'success' && response.data.temp_user_id && response.data.register_exp) {
          this.router.navigate(['/auth/OTP', { user_id: response.data.temp_user_id, pageName: 'register' }]);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  goLogin() {
    this.router.navigate(['auth/login']);
  }

}
