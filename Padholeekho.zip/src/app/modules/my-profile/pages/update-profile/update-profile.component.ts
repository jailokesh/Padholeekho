import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { ApiService } from '../../../../core/services'
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { UpdateProfileService } from '../../services'
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  profileupdateForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  message: any;
  url: any; 
  error: any;;
  

  constructor(private formBuilder: FormBuilder, private _sanitizer: DomSanitizer, private apiService: ApiService, private updateprofileService : UpdateProfileService) {
    this.profileupdateForm = this.formBuilder.group({
      name: ["", [Validators.required]],
      email: ["", [Validators.required, Validators.email]],
      image: [""],
      user_id: [""]
    })
  }

  get f() {
    return this.profileupdateForm.controls;
  }

  updateprofile() {
    this.submitted = true;
    if (this.profileupdateForm.invalid) {
      return;
    }
    this.updateprofileService.updateprofileApi(this.profileupdateForm.value).pipe(
      tap(response => {
        if (response.status == "success") {
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error))
    ).subscribe();
    console.log(this.profileupdateForm.value);
  } 

  goLogin() {
    console.log('Hi');
  }

  ngOnInit() {
    this.url = 'assets/Images/Myprofile/Profile.png';
  }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const formData = new FormData();
      formData.append('file', file);
      this.profileupdateForm.get('image').setValue(formData);
      this.profileupdateForm.get('user_id').setValue(localStorage.getItem('user_Id'));
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
      }
    }
  }

  sanitizeImage(image: string) {
    return this._sanitizer.bypassSecurityTrustStyle(`url(${image})`);
  } 

}
